//
//  ZaigIosOCR.h
//  ZaigIosOCR
//
//  Created by Gabriel Scherer Schwening on 11/02/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ZaigIosOCR.
FOUNDATION_EXPORT double ZaigIosOCRVersionNumber;

//! Project version string for ZaigIosOCR.
FOUNDATION_EXPORT const unsigned char ZaigIosOCRVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZaigIosOCR/PublicHeader.h>


