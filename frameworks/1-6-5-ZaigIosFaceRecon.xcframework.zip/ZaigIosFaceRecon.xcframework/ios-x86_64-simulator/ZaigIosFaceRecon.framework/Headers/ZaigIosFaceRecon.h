//
//  ZaigIosFaceRecon.h
//  ZaigIosFaceRecon
//
//  Created by Gabriel Scherer Schwening on 17/02/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ZaigIosFaceRecon.
FOUNDATION_EXPORT double ZaigIosFaceReconVersionNumber;

//! Project version string for ZaigIosFaceRecon.
FOUNDATION_EXPORT const unsigned char ZaigIosFaceReconVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZaigIosFaceRecon/PublicHeader.h>


